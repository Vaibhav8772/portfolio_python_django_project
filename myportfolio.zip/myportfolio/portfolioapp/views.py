from django.shortcuts import render, redirect
from portfolioapp.models import Information
from django.contrib import messages

def home(request):
    return render(request, "index.html")

def portfolio(request):
    return render(request, "portfolio.html")


def aboutus(request):
    return render(request, "aboutus.html")


def services(request):
    return render(request, "services.html")

def contactus(request):
    if request.method == "POST":
        name = request.POST.get("name")
        email = request.POST.get("email")
        project = request.POST.get("project")
        message = request.POST.get("message")
        
        # Create the Information object and save it
        en = Information(name=name, email=email, project=project, message=message)
        en.save()

        # Get the id of the saved object
        ok = en.id
        
        # Check if the id is not None, which means the object was saved successfully
        if ok:
            messages.success(request, "Your message has been successfully sent!")
        
        # Redirect to the contactus page to avoid resubmission on refresh
        return redirect('contactus')  # Redirect to the same page to avoid re-submission

    return render(request, "contactus.html")
