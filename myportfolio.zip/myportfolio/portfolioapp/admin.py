from django.contrib import admin
from portfolioapp.models import Information

admin.site.register(Information)
# Register your models here.
